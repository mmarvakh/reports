# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['demo_project']

package_data = \
{'': ['*']}

install_requires = \
['flask==1.1.2']

setup_kwargs = {
    'name': 'demo-project',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Marvakh Mark',
    'author_email': 'mmarvakh@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
